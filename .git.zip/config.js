export const prefix = "/";

export const whitelist = [];
